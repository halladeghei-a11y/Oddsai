import { NextRequest, NextResponse } from "next/server";
import { getFootballDataMatches } from "@/lib/providers/football-data";
import { getStakeOdds } from "@/lib/providers/stake-odds";
import { demoMatches } from "@/lib/sample-data";
import { dateKey } from "@/lib/date";

export const dynamic = "force-dynamic";
export async function GET(request: NextRequest) {
  const date = request.nextUrl.searchParams.get("date") ?? dateKey(new Date());
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return NextResponse.json({ error: "Ugyldig dato" }, { status: 400 });
  try {
    const fixtures = await getFootballDataMatches(date);
    let odds = new Map();
    try { odds = await getStakeOdds(fixtures.map(m => m.id)); } catch { /* fixture list remains useful without odds */ }
    const matches = fixtures.map(m => ({ ...m, odds: odds.get(m.id) ?? null }));
    return NextResponse.json({ matches, source: "live" }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    // Explicit demo fallback for local development only. It must not masquerade as real fixtures.
    if (process.env.NODE_ENV !== "production" && !process.env.FOOTBALL_DATA_API_TOKEN) {
      const matches = demoMatches.filter(m => dateKey(new Date(m.kickoff)) === date);
      return NextResponse.json({ matches, source: "demo" });
    }
    return NextResponse.json({ matches: [], source: "error", error: error instanceof Error ? error.message : "Fixture provider unavailable" }, { status: 503 });
  }
}
